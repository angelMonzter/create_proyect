
					<?php 
						require 'templates/header.php';
					?>

						<p>Hola mundo</p>
						
					<?php 
						require 'templates/footer.php';
					?>